import tempfile
import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
import logging

import urllib.request
from database.database import *
from keyboard import *
from all_text import *
from function import *

admin_panel = AdminPanelTelegram.get()
telegram_token = admin_panel.telegram_token

bot = telebot.TeleBot(telegram_token)
logging.basicConfig(level=logging.INFO)


@bot.message_handler(commands=['start'])
def start(message):
    if Users.get_or_none(Users.user_id == message.from_user.id):
        bot.send_message(message.chat.id, start_text(message.from_user.first_name), parse_mode='HTML', reply_markup=create_keyboard())
    else:
        captcha = captcha_generate()
        bot.send_photo(message.chat.id, captcha[0], caption=captcha_text(), reply_markup=ReplyKeyboardRemove())
        bot.register_next_step_handler(message, captcha_check, captcha_result=captcha[1])


def captcha_check(message, captcha_result):
    user_answer = message.text.strip().lower()

    if user_answer == captcha_result:
        Users.create(user_id=message.from_user.id, username=message.from_user.username, captcha='True')
        bot.send_message(
            message.chat.id, start_text(message.from_user.first_name), parse_mode='HTML',reply_markup=create_keyboard()
        )
    else:
        bot.send_message(message.chat.id, 'Неправильный ответ на капчу')


@bot.message_handler(func=lambda message: True, content_types=['text'])
def handle_message(message):
    button_name = message.text

    buttons = AdminPanel.select()

    if not buttons:
        bot.send_message(message.chat.id, "Кнопок нет")
        return

    try:
        button = buttons.where(AdminPanel.button_name == button_name).get()
    except AdminPanel.DoesNotExist:
        bot.send_message(message.chat.id, "Неправильная кнопка")
        return

    
    try:
        with urllib.request.urlopen('https:' + button.photo_name) as url:
            with tempfile.NamedTemporaryFile(delete=True) as tf:
                tf.write(url.read())
                tf.flush()
                tf.seek(0)
                bot.send_photo(message.chat.id, photo=tf, caption=button.text_name, parse_mode='HTML')

    except:
        bot.send_message(message.chat.id, text=button.text_name)


        
        
   

if __name__ == '__main__':
    bot.polling()
