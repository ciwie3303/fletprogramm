import os
import random
import requests
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
from aiogram import types
from database.database import *
from main import *
import schedule
import time
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.utils import executor


async def captcha_generate():
    with open('captcha_words.txt', 'r', encoding='utf-8') as file:
        file = file.readlines()
        text = random.choice(file).strip().lower()
    im = Image.new("RGB", (570, 300), (random.randint(1, 255), random.randint(1, 255), random.randint(1, 255)))
    font = ImageFont.truetype('fonts/DR.ttf', size=60)
    draw_text = ImageDraw.Draw(im)
    if len(text) == 10:
        draw_text.text(
            (random.randint(30, 150), random.randint(10, 230)),
            text,
            font=font,
            fill=(255, 255, 255))

    elif len(text) > 10:
        draw_text.text(
            (random.randint(30, 100), random.randint(10, 230)),
            text,
            font=font,
            fill=(255, 255, 255))

    else:
        draw_text.text(
            (random.randint(30, 300), random.randint(10, 230)),
            text,
            font=font,
            fill=(255, 255, 255))
    byte_io = BytesIO()
    im.save(byte_io, 'PNG')
    byte_io.seek(0)
    return [types.InputFile(byte_io), text]
