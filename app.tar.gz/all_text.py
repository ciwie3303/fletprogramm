from function import *

def captcha_text():
    text = '''
<b>Введи РУССКОЕ слово, которое указано на картинке для доступа к боту:</b>

<i>Я буду тебя игнорировать, пока не введешь правильное слово 🦦</i>'''
    return text

def start_text(first_name):
    text = f'''<b>
{first_name}, добро пожаловать</b>'''
    return text