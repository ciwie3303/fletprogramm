from peewee import *

db = SqliteDatabase('database/database.db')


class Users(Model):  
    user_id = IntegerField(primary_key=True)
    username = CharField()
    captcha = CharField()
    class Meta:
        database = db

class AdminPanel(Model):  
    button_name = CharField()
    text_name = CharField()
    photo_name = CharField()
    class Meta:
        database = db


class AdminPanelTelegram(Model):  
    id = IntegerField(primary_key=True)
    telegram_token = CharField()
    class Meta:
        database = db


class AdminPanelChat(Model): 
    id = IntegerField(primary_key=True)
    chats_send = CharField()
    class Meta:
        database = db

if __name__ == '__main__':
    # Users.create_table()
    # AdminPanel.create_table()
    # AdminPanelChat.create_table()
    # AdminPanelTelegram.create_table()
    db.connect()