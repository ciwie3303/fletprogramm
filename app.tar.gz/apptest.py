import tempfile
import flet as ft
from flet import theme
import urllib.request
from database.database import *
from main import *
import time


should_stop_sending = False

def main(page):
    page.bgcolor = ft.colors.WHITE
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    
    def change_telegram_token(new_token):
        try:
            admin_panel = AdminPanelTelegram.get(AdminPanelTelegram.id == 1)
            admin_panel.telegram_token = new_token
            admin_panel.save()
        except Exception as e:
            print(f"[БАЗА ДАННЫХ] Произошла ошибка: {str(e)}")


    def save_chats_send(chats):
        chats_list = chats.split(",")
        chats_str = ",".join(chats_list)  # Преобразование списка обратно в строку
        try:
            admin_panelchat = AdminPanelChat.get(AdminPanelChat.id == 1)
            admin_panelchat.chats_send = chats_str
            admin_panelchat.save()
        except Exception as e:
            print(f"An error occurred: {str(e)}")


    def add_data_to_database(button_name, text_name, photo_name):
        new_entry = AdminPanel(button_name=button_name, text_name=text_name, photo_name=photo_name)
        new_entry.save()

    def send_mailing(sms, hour, img):
        global should_stop_sending

        while not should_stop_sending:
            admin_panel = AdminPanelChat.get(AdminPanelChat.id == 1)
            chats = admin_panel.chats_send.split(",")
            message_text = sms
            image_url = img
            
            interval_seconds = hour

            for item in chats:
                try:
                    chat = AdminPanelChat.get(AdminPanelChat.chats_send == item)
                    if image_url:
                        with urllib.request.urlopen('https:' + image_url) as url:
                            with tempfile.NamedTemporaryFile(delete=True) as tf:
                                tf.write(url.read())
                                tf.flush()
                                tf.seek(0)
                                bot.send_photo(chat.chats_send, photo=tf, caption=message_text, parse_mode='HTML')
                    else:
                        bot.send_message(chat.chats_send, text=message_text, parse_mode='HTML')
                except Exception as err:
                    print(err, item)

            time.sleep(interval_seconds)


    def stop_sending():
        global should_stop_sending
        should_stop_sending = True


    page.title = "Веб-панель от бота"
    page.update()
 

    chagetoken = ft.Ref[ft.TextField]()
    chat_lst = ft.Ref[ft.TextField]()
    btn_name = ft.Ref[ft.TextField]()
    start_btn = ft.Ref[ft.TextField]()
    
    # Обработчик нажатия кнопки
    def chagetoken_click(e):
        page.add(ft.Text("[БАЗА ДАННЫХ] Сохранение токена прошло успешно"))
        change_telegram_token(chagetoken.current.value)
        chagetoken.current.value = ""
        page.update()

    def cchat_lst_click(e):
        page.add(ft.Text("[БАЗА ДАННЫХ] Сохранение чатов прошло успешно"))
        save_chats_send(chat_lst.current.value)
        chat_lst.current.value = ""
        page.update()

    def btn_lst_click(e):
        test = btn_name.current.value.split(":")
        
        page.add(ft.Text("[БАЗА ДАННЫХ] Сохранение кнопки прошло успешно"))
        add_data_to_database(test[0], test[1], test[3])
        btn_name.current.value = ""
        page.update()

    def btn_spamstart(e):
        global should_stop_sending
        should_stop_sending = False
        testspam = start_btn.current.value.split(":")
        page.add(ft.Text("[ЛОГ] Автопост работает"))
        send_mailing(testspam[0], int(testspam[1]), testspam[3])
        start_btn.current.value = ""
        page.update()

    def btn_spamstop(e):
        page.add(ft.Text("[ЛОГ] Автопост не работает"))
        stop_sending()
        page.update()

    startspam = ft.FilledButton("Запустить спам", on_click=btn_spamstart, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)))
    stopspam = ft.FilledButton("Остановить спам", on_click=btn_spamstop, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)))
    



    entrieRow = ft.Row(
        controls=[startspam,stopspam], 
        alignment=ft.MainAxisAlignment.CENTER

    )
    c = ft.Row(controls=[
        ft.TextField(ref=chagetoken, label="Введите токен", width=400),
        ft.FilledButton("Изменить токен", on_click=chagetoken_click, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)))
        
    
    ], alignment=ft.MainAxisAlignment.CENTER)

    c1 = ft.Row(controls=[
        ft.TextField(ref=chat_lst, label="Введите чаты(через ',')", width=400),
        ft.FilledButton("Добавить чаты", on_click=cchat_lst_click, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)))
    
    
    ], alignment=ft.MainAxisAlignment.CENTER)

    c2 = ft.Row(controls=[
        ft.TextField(ref=btn_name,  label="Введите название кнопки:текст кнопки:картинку", width=400),
        ft.FilledButton("Добавить кнопку", on_click=btn_lst_click, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=5)))
    
    ],alignment=ft.MainAxisAlignment.CENTER)

    c3 = ft.Row(controls=[
        ft.TextField(ref=start_btn,  label="Введите текст:время(в секундах):картинку", width=400),
        
    ],alignment=ft.MainAxisAlignment.CENTER)

    
    page.add(c, c1, c2, c3, entrieRow)


    page.theme = theme.Theme(color_scheme_seed='green') 
    page.update()
    
ft.app(target=main, view=ft.AppView.WEB_BROWSER)
