import telebot
from database.database import *

# Function to create ReplyKeyboardMarkup from the database
def create_keyboard():
    keyboard = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)

    # Get all records from the database
    buttons = AdminPanel.select()

    # Create buttons based on the data from the database
    for button in buttons:
        keyboard.add(telebot.types.KeyboardButton(button.button_name))

    return keyboard
