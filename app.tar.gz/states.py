from aiogram.dispatcher.filters.state import State, StatesGroup


class CaptchaState(StatesGroup):
    captcha_text = State()
